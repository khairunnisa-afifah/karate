<footer class="bg-light text-center text-muted py-4 mt-5 border-top">
  <div class="container">
    <p class="mb-1">&copy; <?= date("Y"); ?> SMK NEGERI 64 JAKARTA. </p>
    <small>Dibuat oleh Khaiurnnisa Afifah</small>
  </div>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>