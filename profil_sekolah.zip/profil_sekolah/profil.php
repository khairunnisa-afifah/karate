<?php include 'header.php'; ?>
<link rel="stylesheet" href="style.css">

<style>
  .section-title {
    font-weight: bold;
    color: #2c3e50;
  }

  body {
    background: #f7f9fc;
  }

  .profil-box {
    background: white;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    padding: 25px;
    margin-bottom: 30px;
  }

  ul li {
    margin-bottom: 10px;
  }

  .carousel img {
    height: 400px;
    object-fit: cover;
  }

  .carousel-inner {
    border-radius: 12px;
    overflow: hidden;
  }

  .btn-custom {
    background-color: #0069d9;
    color: white;
    border-radius: 30px;
  }
</style>

<div class="container my-5">
  <h2 class="text-center section-title mb-5">Profil SMKN 64 Jakarta</h2>

  <div class="profil-box">
    <h4 class="section-title">Sejarah Singkat</h4>
    <p>SMKN 64 Jakarta didirikan sebagai bentuk komitmen pemerintah dalam menyediakan pendidikan kejuruan berkualitas di wilayah Jakarta Timur. Sejak berdiri, sekolah ini telah mengalami perkembangan pesat baik dari segi fasilitas, jumlah siswa, maupun prestasi yang diraih.</p>
  </div>

  <div class="profil-box">
    <h4 class="section-title">Visi</h4>
    <p><em>"Memiliki tamatan yang Berbudi pekerti luhur, Berkarakter, Mandiri, Berprestasi dan Berjiwa Wirausaha"</em></p>
  </div>

  <div class="profil-box">
    <h4 class="section-title">Misi</h4>
    <ul>
      <li>Mengimplementasikan 5S (Senyum, Sapa, Salam, Sopan dan Santun).</li>
      <li>Membangun peserta didik menjadi seseorang yang memiliki sikap profesional.</li>
      <li>Mengarahkan peserta didik untuk meningkatkan potensi dan keahlian diri melalui pelatihan di dalam maupun di luar lingkungan sekolah.</li>
      <li>Menyiapkan tamatan agar mendapatkan prestasi juara di tingkat nasional dengan pelatihan di setiap kompetensi.</li>
      <li>Mengarahkan peserta didik mempunyai jiwa wirausaha melalui pelajaran kewirausahaan.</li>
    </ul>
  </div>

  <div class="profil-box">
    <h4 class="section-title mb-4">Galeri Sekolah</h4>

    <div id="galeriCarousel" class="carousel slide" data-bs-ride="carousel">
      <div class="carousel-inner">
        <div class="carousel-item active">
          <img src="assets/foto1.jpeg" class="d-block w-100" alt="Foto 1">
        </div>
        <div class="carousel-item">
          <img src="assets/foto2.jpeg" class="d-block w-100" alt="Foto 2">
        </div>
        <div class="carousel-item">
          <img src="assets/foto3.jpeg" class="d-block w-100" alt="Foto 3">
        </div>
      </div>
      <button class="carousel-control-prev" type="button" data-bs-target="#galeriCarousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon bg-dark rounded-circle p-2" aria-hidden="true"></span>
        <span class="visually-hidden">Sebelumnya</span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#galeriCarousel" data-bs-slide="next">
        <span class="carousel-control-next-icon bg-dark rounded-circle p-2" aria-hidden="true"></span>
        <span class="visually-hidden">Berikutnya</span>
      </button>
    </div>
  </div>
</div>

<?php include 'footer.php'; ?>
