<?php include 'header.php'; ?>
<link rel="stylesheet" href="style.css">

<div class="container my-5">
  <h2 class="text-center mb-4">Kontak Kami</h2>

  <div class="row">
    <!-- Informasi Kontak -->
    <div class="col-md-6 mb-4">
      <h5>Informasi Sekolah</h5>
      <ul class="list-unstyled">
        <li><strong>Alamat:</strong> Jl. Cipayung Raya No.1, Cipayung, Jakarta Timur</li>
        <li><strong>Telepon:</strong> (021) 12345678</li>
        <li><strong>Email:</strong> smkn64jakarta@gmail.com</li>
        <li><strong>Jam Operasional:</strong> Senin - Jumat, 07.00 - 15.00 WIB</li>
      </ul>

      <!-- Google Maps Embed -->
      <div class="mt-3">
        <iframe
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1983.2387935895278!2d106.8928475!3d-6.3123835!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69edb0f8a62081%3A0x4e46c4be3047f741!2sSMKN%2064%20Jakarta!5e0!3m2!1sid!2sid!4v1712040839267"
          width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"
          referrerpolicy="no-referrer-when-downgrade">
        </iframe>
      </div>
    </div>

    <!-- Formulir Kontak -->
    <div class="col-md-6">
      <h5>Kirim Pesan</h5>
      <form action="simpan_pesan.php" method="POST">
    <input type="text" name="nama" required placeholder="Nama">
    <input type="email" name="email" required placeholder="Email">
    <textarea name="pesan" required placeholder="Tulis pesan..."></textarea>
    <button type="submit">Kirim</button>
</form>

    </div>
  </div>
</div>

<?php include 'footer.php'; ?>
