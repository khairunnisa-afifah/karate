<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

include '../koneksi.php';

if (!isset($_GET['id'])) {
    header("Location: dashboard.php");
    exit;
}

$id = intval($_GET['id']);

$query = "DELETE FROM berita WHERE id = $id";

if (mysqli_query($conn, $query)) {
    header("Location: dashboard.php");
    exit;
} else {
    echo "Gagal menghapus berita: " . mysqli_error($conn);
}
