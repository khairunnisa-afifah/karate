<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

include '../koneksi.php';

// Cek id berita dari query string
if (!isset($_GET['id'])) {
    header("Location: dashboard.php");
    exit;
}

$id = intval($_GET['id']);

// Ambil data berita dari DB
$result = mysqli_query($conn, "SELECT * FROM berita WHERE id = $id");
if (mysqli_num_rows($result) == 0) {
    header("Location: dashboard.php");
    exit;
}

$berita = mysqli_fetch_assoc($result);

// Proses update data
if (isset($_POST['update'])) {
    $judul = mysqli_real_escape_string($conn, $_POST['judul']);
    $isi   = mysqli_real_escape_string($conn, $_POST['isi']);

    $query = "UPDATE berita SET judul = '$judul', isi = '$isi' WHERE id = $id";

    if (mysqli_query($conn, $query)) {
        header("Location: dashboard.php");
        exit;
    } else {
        $error = "Gagal mengupdate berita: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Berita</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
    <h2 class="mb-4">✏️ Edit Berita</h2>

    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <form method="post" action="">
        <div class="mb-3">
            <label for="judul" class="form-label">Judul Berita</label>
            <input type="text" name="judul" id="judul" class="form-control" value="<?= htmlspecialchars($berita['judul']) ?>" required>
        </div>
        <div class="mb-4">
            <label for="isi" class="form-label">Isi Berita</label>
            <textarea name="isi" id="isi" class="form-control" rows="8" required><?= htmlspecialchars($berita['isi']) ?></textarea>
        </div>
        <button type="submit" name="update" class="btn btn-primary">Update</button>
        <a href="dashboard.php" class="btn btn-secondary">Batal</a>
    </form>
</div>

</body>
</html>
