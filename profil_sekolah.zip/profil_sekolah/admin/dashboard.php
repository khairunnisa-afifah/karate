<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

include '../koneksi.php';

// Ambil data pesan terbaru
$pesan = mysqli_query($conn, "SELECT * FROM pesan ORDER BY id DESC");

// Ambil data berita terbaru
$berita = mysqli_query($conn, "SELECT * FROM berita ORDER BY tanggal DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <title>Dashboard Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>👩‍💻 Dashboard Admin</h1>
        <a href="logout.php" class="btn btn-danger">Logout</a>
    </div>

    <!-- Pesan Masuk -->
    <section class="mb-5">
        <h2>📥 Pesan Masuk</h2>
        <?php if (mysqli_num_rows($pesan) > 0): ?>
            <table class="table table-striped table-hover align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>Nama</th>
                        <th>Email</th>
                        <th>Pesan</th>
                        <th>Tanggal</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($p = mysqli_fetch_assoc($pesan)): ?>
                        <tr>
                            <td><?= htmlspecialchars($p['nama']) ?></td>
                            <td><?= htmlspecialchars($p['email']) ?></td>
                            <td><?= nl2br(htmlspecialchars($p['pesan'])) ?></td>
                            <td><?= $p['tanggal'] ?? '-' ?></td>
                            <td>
                                <a href="hapus_pesan.php?id=<?= $p['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin hapus pesan ini?')">Hapus</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>Tidak ada pesan masuk.</p>
        <?php endif; ?>
    </section>

    <!-- Manajemen Berita -->
    <section>
        <h2>📰 Manajemen Berita</h2>
        <a href="tambah_berita.php" class="btn btn-success mb-3">+ Tambah Berita</a>

        <?php if (mysqli_num_rows($berita) > 0): ?>
            <table class="table table-bordered">
                <thead class="table-dark">
                    <tr>
                        <th>Judul</th>
                        <th>Isi (Preview)</th>
                        <th>Tanggal</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($b = mysqli_fetch_assoc($berita)): ?>
                        <tr>
                            <td><?= htmlspecialchars($b['judul']) ?></td>
                            <td><?= substr(strip_tags($b['isi']), 0, 100) ?>...</td>
                            <td><?= $b['tanggal'] ?></td>
                            <td>
                                <a href="edit_berita.php?id=<?= $b['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                                <a href="hapus_berita.php?id=<?= $b['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin hapus berita ini?')">Hapus</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>Tidak ada berita.</p>
        <?php endif; ?>
    </section>
</div>

</body>
</html>
