<?php include 'header.php'; ?>
<link rel="stylesheet" href="style.css">

<div class="container my-5">
  <h2 class="text-center mb-4">Berita Terbaru</h2>

  <div class="row g-4">
    
    <div class="col-md-6">
      <div class="card h-100 shadow-sm">
        <img src="assets/fotoberita1.jpeg" class="card-img-top" alt="Kunjungan Industri">
        <div class="card-body">
          <h5 class="card-title">Kunjungan Industri ke TVRI</h5>
          <p class="card-text">Siswa kelas XI mengikuti kegiatan kunjungan industri ke TVRI sebagai bagian dari program pembelajaran berbasis industri.</p>
          <a href="berita1.php" class="btn btn-primary btn-sm">Baca Selengkapnya</a>
        </div>
      </div>
    </div>

    <div class="col-md-6">
      <div class="card h-100 shadow-sm">
        <img src="assets/fotoberita3.jpeg" class="card-img-top" alt="Peresmian Gedung">
        <div class="card-body">
          <h5 class="card-title">Peresmian Gedung SMKN 64</h5>
          <p class="card-text">Wakil Ketua Dewan Perwakilan Rakyat Daerah (DPRD) DKI Jakarta Rany Mauliani menghadiri peresmian Gedung Sekolah Menengah Kejuruan (SMK) Negeri 64 Jakarta, Cipayung, Jakarta Timur, Selasa (22/7).</p>
          <a href="berita3.php" class="btn btn-primary btn-sm">Baca Selengkapnya</a>
        </div>
      </div>
    </div>
    
    <div class="col-md-6">
      <div class="card h-100 shadow-sm">
        <img src="assets/fotoberita4.jpeg" class="card-img-top" alt="SPMB Jalur Mutasi">
        <div class="card-body">
          <h5 class="card-title">UPDATE INFORMASI SPMB JALUR MUTASI TAHUN PELAJARAN 2025 / 2026</h5>
          <p class="card-text">Informasi hasil seleksi murid baru jalur mutasi semester ganjil SMK Negeri 64 Jakarta Tahun Pelajaran 2025/2026.</p>
          <a href="berita4.php" class="btn btn-primary btn-sm">Baca Selengkapnya</a>
        </div>
      </div>
    </div>

    <div class="col-md-6">
      <div class="card h-100 shadow-sm">
        <img src="assets/fotoberita2.jpeg" class="card-img-top" alt="Juara Lomba">
        <div class="card-body">
          <h5 class="card-title">Juara Lomba O2SN Tingkat Wilayah</h5>
          <p class="card-text">SMKN 64 Jakarta berhasil meraih juara 1 pada tahun 2024 & juara 3 pada tahun 2025.</p>
          <a href="berita2.php" class="btn btn-primary btn-sm">Baca Selengkapnya</a>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include 'footer.php'; ?>
