<?php include 'header.php'; ?>
<!-- Dibantu dengan framework bootsrapp 5.3 -->

<link rel="stylesheet" href="style.css">

<div class="text-center mb-5">
  <img src="assets/gedung.jpeg" class="img-fluid rounded shadow" alt="Gedung Sekolah" style="max-height: 400px; object-fit: cover; width: 100%;">
</div>


<div class="row align-items-center mb-5">
  <div class="col-md-4 text-center">
    <img src="assets/foto_bukepsek.jpeg" class="img-thumbnail rounded-circle shadow mb-3" style="width: 250px; height: 250px; object-fit: cover;" alt="Kepala Sekolah">
    <h5 class="mb-0">Dewi Puspitasari, S.ST.Par, M.Par</h5>
    <small class="text-muted">Kepala Sekolah SMKN 64 Jakarta</small>
  </div>
  <div class="col-md-8">
    <h2 class="mb-3">Sambutan Kepala Sekolah</h2>
    <p>Sebagai lembaga pendidikan, SMKN 64 Jakarta tanggap dengan perkembangan teknologi tersebut. Dengan dukungan SDM yang dimiliki, sekolah ini siap untuk berkompetisi dengan sekolah lain dalam pelayanan informasi publik. Teknologi Informasi Web khususnya, menjadi sarana bagi SMK Negeri 64 Jakarta untuk memberi pelayanan informasi secara cepat, jelas, dan akuntabel. Dari layanan ini pula, sekolah siap menerima saran dari semua pihak yang akhirnya dapat menjawab Kebutuhan masyarakat.</p>
  </div>
</div>


<h3 class="text-center mb-4">Keunggulan Sekolah Kami</h3>
<div class="row text-center">
  <div class="col-md-4 mb-4">
    <div class="card shadow-sm h-100">
      <div class="card-body">
        <h5 class="card-title">Fasilitas Lengkap</h5>
        <p class="card-text">Laboratorium, ruang photography, perpustakaan dan lingkungan belajar yang nyaman.</p>
      </div>
    </div>
  </div>
  <div class="col-md-4 mb-4">
    <div class="card shadow-sm h-100">
      <div class="card-body">
        <h5 class="card-title">Guru Profesional</h5>
        <p class="card-text">Tenaga pendidik berkualitas dan berpengalaman di bidangnya.</p>
      </div>
    </div>
  </div>
  <div class="col-md-4 mb-4">
    <div class="card shadow-sm h-100">
      <div class="card-body">
        <h5 class="card-title">Program Keahlian</h5>
        <p class="card-text">Terdapat 2 jurusan keahlian yang sesuai kebutuhan dunia kerja, yaitu RPL dan DKV. </p>
      </div>
    </div>
  </div>
</div>

<?php include 'footer.php'; ?>